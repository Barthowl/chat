/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bart
 */
public class ChatServerThread extends Thread {
    
    private boolean run = true;
    private int id;
    private String nombre = "";
    private final Socket servidor;
    DataInputStream flujoE;
    DataOutputStream flujoS;
    private ChatServer server;
    
    
    public String getNombre(){
        return nombre;
    }
    
    public String setNombre(String nombre){
        this.nombre = nombre;
        return nombre;
    }

    public ChatServerThread(ChatServer server , Socket servidor) {
        this.server = server;
        this.servidor = servidor;
        try {
            flujoE = new DataInputStream(servidor.getInputStream());
            flujoS = new DataOutputStream(servidor.getOutputStream());
        } catch (IOException ex) {
            System.out.println("constructor: " + ex.getLocalizedMessage());
            run = false;
        }
    }
    
    @Override
    public void run(){
        String text;
        while(run){
            try {
                text = flujoE.readUTF();
                if(nombre.equals("")){
                    setNombre(text);                
                } else {
                server.broadcast(nombre + "> " + text);
                }
                //flujoS.writeUTF(id + "> " + text);
                //flujoS.flush();
            } catch (IOException ex) {
                System.out.println("run: " + ex.getLocalizedMessage());
                run = false;
            }
        }
    }
    
    public boolean getAlive(){
        return run;
    }
    
    public void send(String text){
        try {
            flujoS.writeUTF(text);
            flujoS.flush();
        } catch (IOException ex) {
            System.out.println("run: " + ex.getLocalizedMessage());
            run = false;
        }
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
}
